# tests/test_characters.py
import unittest
from handlers.characters import send_character_details

class TestCharactersHandler(unittest.TestCase):
    def test_send_character_details(self):
        # Реалізуйте тести для функції send_character_details
        pass

if __name__ == '__main__':
    unittest.main()
